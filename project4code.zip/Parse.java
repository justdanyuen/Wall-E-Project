public class Parse {

    public static final String SAPLING_KEY = "sapling";
    public static final int SAPLING_ID = 1;
    public static final int SAPLING_COL = 2;
    public static final int SAPLING_ROW = 3;
    public static final int SAPLING_HEALTH = 4;
    public static final int SAPLING_HEALTH_LIMIT = 5;
    public static final int SAPLING_ACTION_ANIMATION_PERIOD = 1000; // have to be in sync since grows and gains health at same time
    public static final int SAPLING_NUM_PROPERTIES = 4;

    public static final String HOUSE_KEY = "house";
    public static final int HOUSE_NUM_PROPERTIES = 4;
    public static final int HOUSE_ID = 1;
    public static final int HOUSE_COL = 2;
    public static final int HOUSE_ROW = 3;

    public static final String OBSTACLE_KEY = "obstacle";
    public static final int OBSTACLE_NUM_PROPERTIES = 5;
    public static final int OBSTACLE_ID = 1;
    public static final int OBSTACLE_COL = 2;
    public static final int OBSTACLE_ROW = 3;
    public static final int OBSTACLE_ANIMATION_PERIOD = 4;

    public static final int TREE_NUM_PROPERTIES = 7;
    public static final int TREE_ID = 1;
    public static final int TREE_COL = 2;
    public static final int TREE_ROW = 3;
    public static final int TREE_ANIMATION_PERIOD = 4;
    public static final int TREE_ACTION_PERIOD = 5;
    public static final int TREE_HEALTH = 6;
    public static final String TREE_KEY = "tree";

    public static final String FAIRY_KEY = "fairy";
    public static final int FAIRY_NUM_PROPERTIES = 6;
    public static final int FAIRY_ID = 1;
    public static final int FAIRY_COL = 2;
    public static final int FAIRY_ROW = 3;
    public static final int FAIRY_ANIMATION_PERIOD = 4;
    public static final int FAIRY_ACTION_PERIOD = 5;

    public static final String DUDE_KEY = "dude";
    public static final int DUDE_NUM_PROPERTIES = 7;
    public static final int DUDE_ID = 1;
    public static final int DUDE_COL = 2;
    public static final int DUDE_ROW = 3;
    public static final int DUDE_LIMIT = 4;
    public static final int DUDE_ACTION_PERIOD = 5;
    public static final int DUDE_ANIMATION_PERIOD = 6;
    public static final int BGND_NUM_PROPERTIES = 4;
    public static final int BGND_ID = 1;
    public static final int BGND_COL = 2;
    public static final int BGND_ROW = 3;

    String[] properties;
    ImageStore imageStore;
    WorldModel world;

    public Parse(String[] properties, ImageStore imageStore, WorldModel world){
        this.properties = properties;
        this.imageStore = imageStore;
        this.world = world;
    }

    public boolean parseHouse()
    {
        if (this.properties.length == HOUSE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[HOUSE_COL]),
                    Integer.parseInt(this.properties[HOUSE_ROW]));
            House house = new House(this.properties[HOUSE_ID], pt,
                    this.imageStore.getImageList(HOUSE_KEY));
            this.world.tryAddEntity(house);
        }

        return this.properties.length == HOUSE_NUM_PROPERTIES;
    }

    public boolean parseObstacle()
    {
        if (this.properties.length == OBSTACLE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[OBSTACLE_COL]),
                    Integer.parseInt(this.properties[OBSTACLE_ROW]));
            Obstacle obstacle = new Obstacle(this.properties[OBSTACLE_ID], pt,
                    imageStore.getImageList(OBSTACLE_KEY),
                    Integer.parseInt(this.properties[OBSTACLE_ANIMATION_PERIOD]));
            this.world.tryAddEntity(obstacle);
        }
        return this.properties.length == OBSTACLE_NUM_PROPERTIES;
    }

    public boolean parseTree()
    {
        if (this.properties.length == TREE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[TREE_COL]),
                    Integer.parseInt(this.properties[TREE_ROW]));
            Tree tree = new Tree(this.properties[TREE_ID],
                    pt,
                    imageStore.getImageList(TREE_KEY),
                    Integer.parseInt(properties[TREE_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[TREE_ACTION_PERIOD]),
                    Integer.parseInt(properties[TREE_HEALTH])
            );
            this.world.tryAddEntity(tree);
        }

        return this.properties.length == TREE_NUM_PROPERTIES;
    }

    public boolean parseFairy()
    {
        if (this.properties.length == FAIRY_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[FAIRY_COL]),
                    Integer.parseInt(this.properties[FAIRY_ROW]));
            Fairy fairy = new Fairy(this.properties[FAIRY_ID],
                    pt,
                    imageStore.getImageList(FAIRY_KEY),
                    Integer.parseInt(properties[FAIRY_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[FAIRY_ACTION_PERIOD])
            );
            this.world.tryAddEntity(fairy);
        }

        return this.properties.length == FAIRY_NUM_PROPERTIES;
    }

    public boolean parseDude()
    {
        if (this.properties.length == DUDE_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[DUDE_COL]),
                    Integer.parseInt(this.properties[DUDE_ROW]));

            DudeNotFull dude = new DudeNotFull(this.properties[DUDE_ID],
                    pt,
                    this.imageStore.getImageList(DUDE_KEY),
                    Integer.parseInt(properties[DUDE_ANIMATION_PERIOD]),
                    Integer.parseInt(properties[DUDE_ACTION_PERIOD]),
                    Integer.parseInt(properties[DUDE_LIMIT]),
                    0);

            world.tryAddEntity(dude);
        }

        return this.properties.length == DUDE_NUM_PROPERTIES;
    }

    public boolean parseSapling()
    {
        if (this.properties.length == SAPLING_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[SAPLING_COL]),
                    Integer.parseInt(this.properties[SAPLING_ROW]));
            String id = this.properties[SAPLING_ID];
            int health = Integer.parseInt(this.properties[SAPLING_HEALTH]);
            Sapling sapling = new Sapling(id, pt, this.imageStore.getImageList(SAPLING_KEY), SAPLING_ACTION_ANIMATION_PERIOD, SAPLING_ACTION_ANIMATION_PERIOD, health, SAPLING_HEALTH_LIMIT);
            this.world.tryAddEntity(sapling);
        }

        return this.properties.length == SAPLING_NUM_PROPERTIES;
    }

    public boolean parseBackground()
    {
        if (this.properties.length == BGND_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(this.properties[BGND_COL]),
                    Integer.parseInt(this.properties[BGND_ROW]));
            String id = this.properties[BGND_ID];
            this.world.setBackground(pt, new Background(id, imageStore.getImageList(id)));
        }

        return properties.length == BGND_NUM_PROPERTIES;
    }
}
